# practica12
 practica
